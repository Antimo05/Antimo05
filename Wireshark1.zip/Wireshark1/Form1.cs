﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wireshark1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        public List<String[]> data = new List<String[]>();

        public void CSVParser()
        {

            StreamReader reader = new StreamReader(File.OpenRead("wireshark1.csv"));
            reader.ReadLine();
            reader.ReadLine();
            int i = 0;
            while (!reader.EndOfStream && i < 200)
            {

                string line = reader.ReadLine();
                if (!String.IsNullOrWhiteSpace(line))
                {
                    line = String.Join("", line.Split('"', ' ', '\\', '\"')).Substring(16);
                    string[] values = line.Split(',');
                    
                    data.Add(values);
                }
                i++;
            }


        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            CSVParser();
            dataGridView1.ColumnCount = 9;

            foreach (string[] row in data) {
                dataGridView1.Rows.Add(row);
            }           


            
        }
    }
}

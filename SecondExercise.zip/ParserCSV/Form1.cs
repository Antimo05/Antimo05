﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParserCSV
{
    
    public partial class Form1 : Form
    {
        public List<String[]> data = new List<String[]>();

        public void CSVParser()
        {
            
            StreamReader reader = new StreamReader(File.OpenRead("netflix.csv"));

            int i = 0;
            while (!reader.EndOfStream && i < 200)
            {
               
                string line = reader.ReadLine();
                if (!String.IsNullOrWhiteSpace(line))
                {
                    line = String.Join("", line.Split('"', ' ', '\\', '\"'));
                    string[] values = line.Split(',');
                    data.Add(values);
                }
                i++;
            }

            
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CSVParser();

            foreach (String[] position in data) {
                foreach (String s in position) {
                    richTextBox1.AppendText(s + " ");
                }
                richTextBox1.AppendText("\n");
            }

            richTextBox1.ScrollToCaret();
        }
    }


}

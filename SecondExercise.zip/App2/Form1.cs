﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace App2
{
    public partial class Form1 : Form
    {

        public Random r = new Random();
        public Double sum = 0;
        public int count = 0;
        public int[] a= new int[11];

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Interval = 200;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            double current = r.NextDouble();
            sum += current;
            count++;

            richTextBox1.AppendText("Current: " + current + "\n");
            richTextBox1.AppendText("Avg: " + sum/count + "\n");

            double step = 0.1;
            for(int i = 0; i < 10; i++)
            {
                if ((current >= step * i) && (current < (i + 1) * step))
                    a[i] = a[i] + 1;
            }

            richTextBox1.ScrollToCaret();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            richTextBox1.BackColor = Color.Aqua;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            richTextBox1.AppendText("\n");
            for (int i = 0; i < 10; i++) {
                richTextBox1.AppendText(i*10 + " - " + (i+1)*10 + " |  " + a[i] + "\n");
            }
            richTextBox1.AppendText("\n");
        }
    }
}

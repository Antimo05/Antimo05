﻿Public Class Form1
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.RichTextBox1.Clear()

        'rispetto a C# non vi è bisogno del punto e virgola per ogni statement

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.RichTextBox1.AppendText("Button 1" & vbCrLf)
        'l'andata a capo è diversa rispetto a C# dove bastava usare \n

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.RichTextBox1.AppendText("Button 2" & vbCrLf)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.RichTextBox1.AppendText("Button 3" & vbCrLf)

    End Sub
End Class

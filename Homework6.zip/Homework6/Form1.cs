﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework6
{
    public partial class Form1 : Form
    {
        private List<elem> lista_totale = new List<elem>();
        public int totalRow = 0;
        public List<double> lista = new List<double>();

        public Form1()
        {
            InitializeComponent();
        }

        

        private void btnLoad_Click(object sender, EventArgs e)
        {
            var parsedData = new List<string[]>();
            using (var sr = new StreamReader("menu.csv")) {
                string line;
                sr.ReadLine();
                while ((line = sr.ReadLine()) != null && totalRow < 262)
                {
                    string[] row = line.Split(',');
                    parsedData.Add(row);
                    totalRow++;
                }
            
            }

            foreach (string[] row in parsedData) {
                dataGridView1.Rows.Add(row);
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double mean;
            double variance;
            int number_of_sample = Convert.ToInt32(this.tbSampleSetNumber.Text);
            int set_of_sample = Convert.ToInt32(this.tbNumberOfTimes.Text);

            if (number_of_sample >= totalRow) {
                number_of_sample = totalRow - 2;
                this.tbSampleSetNumber.Text = number_of_sample.ToString();
            }

            fill_list(lista);
            mean = mean_population(lista);
            variance = variance_population(lista, mean);
            tbDistributionOfMean.Text = mean.ToString();
            tbDistributionOfVariance.Text = variance.ToString();

            sampling(lista, number_of_sample, set_of_sample);
            
        }

        void fill_list(List<double> list) {
            string column = this.tbColumn.Text;

            for (int i = 0; i < dataGridView1.ColumnCount; i++) {
                if (dataGridView1.Columns[i].Name == column) {
                    for (int j = 0; j < totalRow; j++) {
                        lista.Add(Convert.ToDouble((string)dataGridView1[i, j].Value));
                    }
                }
            
            }
        }

        double mean_population(List<double> list) {
            double mean;
            double temp_sum = 0;
            for (int i = 0; i < list.Count; i++){
                temp_sum = temp_sum + (double)list[i];
            }
            mean = temp_sum / (double)list.Count;
            return mean;
        }

        double variance_population(List<double> list, double mean) {
            double variance;
            double temp_sum = 0;
            

            for (int i = 0; i < list.Count; i++)
            {
                temp_sum = temp_sum + (Math.Pow((list[i] - mean), 2));
            }
            variance = temp_sum / list.Count;
            return variance;
        }

        void sampling(List<double> list, int n_elem, int n_set) {
            double mean_temp;
            double mean_mean_temp;
            double mean_variance_temp;
            double variance_mean_temp;
            double variance_variance_temp;
            Random rnd = new Random();
            List<double> mean_of_mean = new List<double>();
            List<double> mean_of_variance = new List<double>();

            for (int i = 0; i < n_set; i++) { 
                List<double> list_temp = new List<double> ();
                for (int j = 0; j < n_elem; j++) {
                    int num = rnd.Next(0, list.Count);
                    list_temp.Add(list[num]);
                }
                mean_temp = mean_population(list_temp);
                mean_of_mean.Add(mean_temp);
                mean_of_variance.Add(variance_population(list_temp, mean_temp));

            }

            mean_mean_temp = mean_population(mean_of_mean);
            mean_variance_temp = mean_population(mean_of_variance);
            variance_mean_temp = variance_population(mean_of_mean, mean_mean_temp);
            variance_variance_temp = variance_population(mean_of_variance, mean_population(mean_of_variance));

            tbMeanOfMean.Text = mean_mean_temp.ToString();
            tbMeanOfVariance.Text = mean_variance_temp.ToString();
            tbVarianceOfMean.Text = variance_mean_temp.ToString();
            tbVarianceOfVariance.Text = variance_variance_temp.ToString();
        
        }

    }
}

﻿namespace Homework6
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnLoad = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbColumn = new System.Windows.Forms.TextBox();
            this.tbNumberOfTimes = new System.Windows.Forms.TextBox();
            this.tbSampleSetNumber = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tbDistributionOfMean = new System.Windows.Forms.TextBox();
            this.tbVarianceOfVariance = new System.Windows.Forms.TextBox();
            this.tbMeanOfVariance = new System.Windows.Forms.TextBox();
            this.tbVarianceOfMean = new System.Windows.Forms.TextBox();
            this.tbMeanOfMean = new System.Windows.Forms.TextBox();
            this.tbDistributionOfVariance = new System.Windows.Forms.TextBox();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Protein = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15,
            this.Column16,
            this.Column17,
            this.Column18,
            this.Column19,
            this.Column20,
            this.Protein,
            this.Column21,
            this.Column22,
            this.Column23,
            this.Column24});
            this.dataGridView1.Location = new System.Drawing.Point(13, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1292, 364);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(60, 413);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(279, 57);
            this.btnLoad.TabIndex = 1;
            this.btnLoad.Text = "Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Location = new System.Drawing.Point(60, 493);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(10, 2, 10, 2);
            this.label1.Size = new System.Drawing.Size(124, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "Choose Column";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Location = new System.Drawing.Point(60, 540);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(10, 2, 10, 2);
            this.label2.Size = new System.Drawing.Size(145, 22);
            this.label2.TabIndex = 3;
            this.label2.Text = "Sample set number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Location = new System.Drawing.Point(61, 590);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(10, 2, 10, 2);
            this.label3.Size = new System.Drawing.Size(126, 22);
            this.label3.TabIndex = 4;
            this.label3.Text = "Number of times";
            // 
            // tbColumn
            // 
            this.tbColumn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbColumn.Location = new System.Drawing.Point(215, 493);
            this.tbColumn.MaximumSize = new System.Drawing.Size(200, 38);
            this.tbColumn.Name = "tbColumn";
            this.tbColumn.Size = new System.Drawing.Size(124, 22);
            this.tbColumn.TabIndex = 5;
            this.tbColumn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbNumberOfTimes
            // 
            this.tbNumberOfTimes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbNumberOfTimes.Location = new System.Drawing.Point(215, 590);
            this.tbNumberOfTimes.MaximumSize = new System.Drawing.Size(200, 38);
            this.tbNumberOfTimes.Name = "tbNumberOfTimes";
            this.tbNumberOfTimes.Size = new System.Drawing.Size(124, 22);
            this.tbNumberOfTimes.TabIndex = 6;
            this.tbNumberOfTimes.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbSampleSetNumber
            // 
            this.tbSampleSetNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSampleSetNumber.Location = new System.Drawing.Point(215, 540);
            this.tbSampleSetNumber.MaximumSize = new System.Drawing.Size(200, 38);
            this.tbSampleSetNumber.Name = "tbSampleSetNumber";
            this.tbSampleSetNumber.Size = new System.Drawing.Size(124, 22);
            this.tbSampleSetNumber.TabIndex = 7;
            this.tbSampleSetNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(61, 634);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(279, 57);
            this.btnCalculate.TabIndex = 8;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Location = new System.Drawing.Point(644, 615);
            this.label4.Name = "label4";
            this.label4.Padding = new System.Windows.Forms.Padding(10, 2, 63, 2);
            this.label4.Size = new System.Drawing.Size(254, 22);
            this.label4.TabIndex = 9;
            this.label4.Text = "Mean of the sample variance";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Location = new System.Drawing.Point(644, 566);
            this.label5.Name = "label5";
            this.label5.Padding = new System.Windows.Forms.Padding(10, 2, 61, 2);
            this.label5.Size = new System.Drawing.Size(254, 22);
            this.label5.TabIndex = 10;
            this.label5.Text = "Variance of the sample mean";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Location = new System.Drawing.Point(644, 515);
            this.label6.Name = "label6";
            this.label6.Padding = new System.Windows.Forms.Padding(10, 2, 81, 2);
            this.label6.Size = new System.Drawing.Size(254, 22);
            this.label6.TabIndex = 11;
            this.label6.Text = "Mean of the sample mean";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Location = new System.Drawing.Point(644, 465);
            this.label7.Name = "label7";
            this.label7.Padding = new System.Windows.Forms.Padding(10, 2, 10, 2);
            this.label7.Size = new System.Drawing.Size(254, 22);
            this.label7.TabIndex = 12;
            this.label7.Text = "Distribution of the Variance Population";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Location = new System.Drawing.Point(644, 413);
            this.label8.Name = "label8";
            this.label8.Padding = new System.Windows.Forms.Padding(10, 2, 30, 2);
            this.label8.Size = new System.Drawing.Size(254, 22);
            this.label8.TabIndex = 13;
            this.label8.Text = "Distribution of the Mean Population";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Location = new System.Drawing.Point(644, 669);
            this.label9.Name = "label9";
            this.label9.Padding = new System.Windows.Forms.Padding(10, 2, 43, 2);
            this.label9.Size = new System.Drawing.Size(254, 22);
            this.label9.TabIndex = 14;
            this.label9.Text = "Variance of the sample variance";
            // 
            // tbDistributionOfMean
            // 
            this.tbDistributionOfMean.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbDistributionOfMean.Location = new System.Drawing.Point(943, 413);
            this.tbDistributionOfMean.MaximumSize = new System.Drawing.Size(200, 38);
            this.tbDistributionOfMean.Name = "tbDistributionOfMean";
            this.tbDistributionOfMean.Size = new System.Drawing.Size(166, 22);
            this.tbDistributionOfMean.TabIndex = 15;
            this.tbDistributionOfMean.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbVarianceOfVariance
            // 
            this.tbVarianceOfVariance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbVarianceOfVariance.Location = new System.Drawing.Point(943, 669);
            this.tbVarianceOfVariance.MaximumSize = new System.Drawing.Size(200, 38);
            this.tbVarianceOfVariance.Name = "tbVarianceOfVariance";
            this.tbVarianceOfVariance.Size = new System.Drawing.Size(166, 22);
            this.tbVarianceOfVariance.TabIndex = 16;
            this.tbVarianceOfVariance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbMeanOfVariance
            // 
            this.tbMeanOfVariance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbMeanOfVariance.Location = new System.Drawing.Point(943, 615);
            this.tbMeanOfVariance.MaximumSize = new System.Drawing.Size(200, 38);
            this.tbMeanOfVariance.Name = "tbMeanOfVariance";
            this.tbMeanOfVariance.Size = new System.Drawing.Size(166, 22);
            this.tbMeanOfVariance.TabIndex = 17;
            this.tbMeanOfVariance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbVarianceOfMean
            // 
            this.tbVarianceOfMean.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbVarianceOfMean.Location = new System.Drawing.Point(943, 566);
            this.tbVarianceOfMean.MaximumSize = new System.Drawing.Size(200, 38);
            this.tbVarianceOfMean.Name = "tbVarianceOfMean";
            this.tbVarianceOfMean.Size = new System.Drawing.Size(166, 22);
            this.tbVarianceOfMean.TabIndex = 18;
            this.tbVarianceOfMean.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbMeanOfMean
            // 
            this.tbMeanOfMean.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbMeanOfMean.Location = new System.Drawing.Point(943, 515);
            this.tbMeanOfMean.MaximumSize = new System.Drawing.Size(200, 38);
            this.tbMeanOfMean.Name = "tbMeanOfMean";
            this.tbMeanOfMean.Size = new System.Drawing.Size(166, 22);
            this.tbMeanOfMean.TabIndex = 19;
            this.tbMeanOfMean.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbDistributionOfVariance
            // 
            this.tbDistributionOfVariance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbDistributionOfVariance.Location = new System.Drawing.Point(943, 465);
            this.tbDistributionOfVariance.MaximumSize = new System.Drawing.Size(200, 38);
            this.tbDistributionOfVariance.Name = "tbDistributionOfVariance";
            this.tbDistributionOfVariance.Size = new System.Drawing.Size(166, 22);
            this.tbDistributionOfVariance.TabIndex = 20;
            this.tbDistributionOfVariance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Category";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.Width = 125;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Item";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.Width = 125;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Serving";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.Width = 125;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Size";
            this.Column4.MinimumWidth = 6;
            this.Column4.Name = "Column4";
            this.Column4.Width = 125;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Calories";
            this.Column5.MinimumWidth = 6;
            this.Column5.Name = "Column5";
            this.Column5.Width = 125;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Calories from Fat";
            this.Column6.MinimumWidth = 6;
            this.Column6.Name = "Column6";
            this.Column6.Width = 125;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Total Fat";
            this.Column7.MinimumWidth = 6;
            this.Column7.Name = "Column7";
            this.Column7.Width = 125;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Total Fat (% Daily Value)";
            this.Column8.MinimumWidth = 6;
            this.Column8.Name = "Column8";
            this.Column8.Width = 125;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Saturated Fat";
            this.Column9.MinimumWidth = 6;
            this.Column9.Name = "Column9";
            this.Column9.Width = 125;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "Saturated Fat (% Daily Value)";
            this.Column10.MinimumWidth = 6;
            this.Column10.Name = "Column10";
            this.Column10.Width = 125;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "Trans Fat";
            this.Column11.MinimumWidth = 6;
            this.Column11.Name = "Column11";
            this.Column11.Width = 125;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "Cholesterol";
            this.Column12.MinimumWidth = 6;
            this.Column12.Name = "Column12";
            this.Column12.Width = 125;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "Cholesterol (% Daily Value)";
            this.Column13.MinimumWidth = 6;
            this.Column13.Name = "Column13";
            this.Column13.Width = 125;
            // 
            // Column14
            // 
            this.Column14.HeaderText = "Sodium";
            this.Column14.MinimumWidth = 6;
            this.Column14.Name = "Column14";
            this.Column14.Width = 125;
            // 
            // Column15
            // 
            this.Column15.HeaderText = "Sodium (% Daily Value)";
            this.Column15.MinimumWidth = 6;
            this.Column15.Name = "Column15";
            this.Column15.Width = 125;
            // 
            // Column16
            // 
            this.Column16.HeaderText = "Carbohydrates";
            this.Column16.MinimumWidth = 6;
            this.Column16.Name = "Column16";
            this.Column16.Width = 125;
            // 
            // Column17
            // 
            this.Column17.HeaderText = "Carbohydrates (% Daily Value)";
            this.Column17.MinimumWidth = 6;
            this.Column17.Name = "Column17";
            this.Column17.Width = 125;
            // 
            // Column18
            // 
            this.Column18.HeaderText = "Dietary Fiber";
            this.Column18.MinimumWidth = 6;
            this.Column18.Name = "Column18";
            this.Column18.Width = 125;
            // 
            // Column19
            // 
            this.Column19.HeaderText = "Dietary Fiber (% Daily Value)";
            this.Column19.MinimumWidth = 6;
            this.Column19.Name = "Column19";
            this.Column19.Width = 125;
            // 
            // Column20
            // 
            this.Column20.HeaderText = "Sugars";
            this.Column20.MinimumWidth = 6;
            this.Column20.Name = "Column20";
            this.Column20.Width = 125;
            // 
            // Protein
            // 
            this.Protein.HeaderText = "Column21";
            this.Protein.MinimumWidth = 6;
            this.Protein.Name = "Protein";
            this.Protein.Width = 125;
            // 
            // Column21
            // 
            this.Column21.HeaderText = "Vitamin A (% Daily Value)";
            this.Column21.MinimumWidth = 6;
            this.Column21.Name = "Column21";
            this.Column21.Width = 125;
            // 
            // Column22
            // 
            this.Column22.HeaderText = "Vitamin C (%Daily Value)";
            this.Column22.MinimumWidth = 6;
            this.Column22.Name = "Column22";
            this.Column22.Width = 125;
            // 
            // Column23
            // 
            this.Column23.HeaderText = "Calcium (% Daily Value)";
            this.Column23.MinimumWidth = 6;
            this.Column23.Name = "Column23";
            this.Column23.Width = 125;
            // 
            // Column24
            // 
            this.Column24.HeaderText = "Iron (% Daily Value)";
            this.Column24.MinimumWidth = 6;
            this.Column24.Name = "Column24";
            this.Column24.Width = 125;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1317, 713);
            this.Controls.Add(this.tbDistributionOfVariance);
            this.Controls.Add(this.tbMeanOfMean);
            this.Controls.Add(this.tbVarianceOfMean);
            this.Controls.Add(this.tbMeanOfVariance);
            this.Controls.Add(this.tbVarianceOfVariance);
            this.Controls.Add(this.tbDistributionOfMean);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.tbSampleSetNumber);
            this.Controls.Add(this.tbNumberOfTimes);
            this.Controls.Add(this.tbColumn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbColumn;
        private System.Windows.Forms.TextBox tbNumberOfTimes;
        private System.Windows.Forms.TextBox tbSampleSetNumber;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbDistributionOfMean;
        private System.Windows.Forms.TextBox tbVarianceOfVariance;
        private System.Windows.Forms.TextBox tbMeanOfVariance;
        private System.Windows.Forms.TextBox tbVarianceOfMean;
        private System.Windows.Forms.TextBox tbMeanOfMean;
        private System.Windows.Forms.TextBox tbDistributionOfVariance;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Protein;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column22;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column23;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column24;
    }
}

